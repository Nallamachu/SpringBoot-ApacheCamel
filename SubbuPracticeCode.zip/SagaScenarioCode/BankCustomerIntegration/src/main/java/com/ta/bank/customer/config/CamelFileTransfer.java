package com.ta.bank.customer.config;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/*
 * @author:	Subbu
 * @class:	CamelFileTransfer.java
 * @description:	configure method contains the logic for moving file from source to destination location.
 * This is out of scenario
*/
@Component
public class CamelFileTransfer extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("file:C:\\Users\\snallamachu\\Downloads\\examples\\BankCustomerIntegration\\BankCustomerIntegration\\source")
				.to("file:C:\\Users\\snallamachu\\Downloads\\examples\\BankCustomerIntegration\\BankCustomerIntegration\\destination")
				.onCompletion().log("Files moved successfully from source to destination")
				.throwException(new Exception("Failed to move files from source to destination"));
	}

}
