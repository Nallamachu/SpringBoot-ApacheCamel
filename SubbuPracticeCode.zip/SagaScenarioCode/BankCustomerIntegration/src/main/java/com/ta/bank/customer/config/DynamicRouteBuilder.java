package com.ta.bank.customer.config;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;

import com.ta.common.bean.Customer;

public final class DynamicRouteBuilder extends RouteBuilder {
	private final String from;
    private final String to;
    private final Customer currentCustomer;

    public DynamicRouteBuilder(CamelContext context, String from, String to, Customer currentCustomer) {
        super(context);
        this.from = from;
        this.to = to;
        this.currentCustomer = currentCustomer;
    }

	@Override
	public void configure() throws Exception {
		from(from).to(to).log("Cancelled/Removed Customer details for Customer Id: "+currentCustomer.getId())
			.onException(Exception.class).log("Failed to delete Customer with Id: "+currentCustomer.getId());
	}
}
