Steps to configure:
-------------------------------------
1. Import CommonBeans project and build to generate Jar file. Because CommonBeans is the common dependecy across all other projects.
2. Import All other projects and build.

Projects run in the same order
-------------------------------------
1. CommonBeans
2. BankApplication
3. AddressApplication
4. CustomerApplication
5. BankCustomerIntegration

Note: BankCustomerIntegration has the actual logic of Saga scenario (CamelPushingData.java).
